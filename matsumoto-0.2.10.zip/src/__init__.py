"""
This is what Mythic's top-level __init__.py looks like:
https://github.com/MythicMeta/ExampleContainers/blob/main/Payload_Type/python_services/basic_python_agent/__init__.py
"""
