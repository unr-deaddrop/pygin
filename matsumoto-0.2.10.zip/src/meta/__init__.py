"""
This is a non-functional library with various static definitions and
utility routines.
"""
