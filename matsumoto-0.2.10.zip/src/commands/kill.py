"""
Clean up all resources used by the agent and start the shutdown process.
"""
