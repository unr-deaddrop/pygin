"""
Command allowing the user to execute arbitrary Python.
"""
