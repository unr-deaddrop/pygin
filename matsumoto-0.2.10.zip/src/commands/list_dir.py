"""
Command implementing simple directory listing, including a renderer.

The main purpose of this command is to demonstrate a basic command renderer.
"""
