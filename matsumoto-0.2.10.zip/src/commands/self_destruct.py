"""
Uninstall the agent.
"""
