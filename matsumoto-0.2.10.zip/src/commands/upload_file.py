"""
Allows a user to write a file to disk from a server.
"""
