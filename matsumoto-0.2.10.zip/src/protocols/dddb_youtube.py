"""
dddb-specific routines for operating over YouTube.
"""
