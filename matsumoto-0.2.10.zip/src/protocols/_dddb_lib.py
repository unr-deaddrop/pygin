"""
Generic routines applicable to operating dddb over arbitrary platforms.

This does not expose a subclass of ProtocolBase; it simply provides high-level
routines that are applicable for the dddb-based protocols.
"""
