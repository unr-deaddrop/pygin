"""
This module represents the "core" of the agent, containing the code used for
administrative tasks.
"""
